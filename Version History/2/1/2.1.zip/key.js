if (keyDefined != true) {
	var keyDefined = true;
	var controlDown = false;
	function keyGoesDown(e) {
		if (e.keyCode == 17) {
			controlDown = true;
		}
		else if ((e.keyCode == 73) && (controlDown)) {
	    	chrome.extension.sendRequest("switchTabs");
		}
	}
	function keyGoesUp(e){
		if (e.keyCode == 17) {
			controlDown = false;
		}
	}
	window.addEventListener("keydown", keyGoesDown, false);
	window.addEventListener("keyup", keyGoesUp, false);
}