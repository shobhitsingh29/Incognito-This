var keyDefined;
if (keyDefined != true) {
	keyDefined = true;
	var controlDown = false;
	window.addEventListener("keydown", function(e) {
		chrome.extension.sendRequest("autoClose");
		if (e.keyCode == 17) {
			controlDown = true;
		}
		else if ((e.keyCode == 66) && (controlDown)) {
	    	chrome.extension.sendRequest("switchTabs");
		}
	}, false);
	window.addEventListener("keyup", function(e){
		if (e.keyCode == 17) {
			controlDown = false;
		}
	}, false);
	window.addEventListener("mousedown", function(e){
		chrome.extension.sendRequest("autoClose");
	}, false);
}