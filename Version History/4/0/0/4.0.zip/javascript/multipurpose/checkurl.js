﻿function checkUrl(url) {
	return ((url.indexOf("chrome") != 0) || (url.substr(0,15) == "chrome://newtab"));
}