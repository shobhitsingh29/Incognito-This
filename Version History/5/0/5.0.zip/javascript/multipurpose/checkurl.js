﻿function checkUrl(url) {
	if ((url !== undefined) && (url !== null)) {
		return ((url.toLowerCase().indexOf("chrome") != 0) || (url.toLowerCase().substr(0,15) == "chrome://newtab"));
	}
}