﻿chrome.extension.onMessage.addListener(function(request, sender, respond){
	if (request == "back") {
		window.history.back();
	}
});